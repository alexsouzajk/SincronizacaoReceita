package br.com.alex.SincronizacaoReceita;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SincronizacaoReceitaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SincronizacaoReceitaApplication.class, args);
		
		System.out.println("Início da rotina de atualização de contas!");
		System.out.println("Arquivo: " + args[0]);
		
		List<String> arquivo = null;
		try {
			arquivo = lerArquivo(args[0]);
			atualizarContas(arquivo);
		} catch (IOException e) {
			System.out.println("Erro ao ler arquivo: " + e.getMessage());
		}

	}

	private static void atualizarContas(List<String> arquivo) throws IOException {

		ReceitaService receitaService = new ReceitaService();
		List<String> linhas = new ArrayList<>();

		arquivo.forEach(linha -> {

			String[] contaAtualizar = linha.split(";");
			String agencia = contaAtualizar[0];
			String conta = contaAtualizar[1].replace("-", "");
			double saldo = Double.valueOf(contaAtualizar[2].replace(",", "."));
			String status = contaAtualizar[3];

			String[] salvarArquivo = new String[5];
			salvarArquivo[0] = agencia;
			salvarArquivo[1] = contaComDigito(conta);
			salvarArquivo[2] = String.valueOf(saldo).replace(".", ",");
			salvarArquivo[3] = status;

			try {
				boolean atualizado = receitaService.atualizarConta(agencia, conta, saldo, status);

				if (atualizado) {
					salvarArquivo[4] = "sucesso";
					linhas.add(geraLinha(salvarArquivo));
				} else {
					salvarArquivo[4] = "erro";
					linhas.add(geraLinha(salvarArquivo));
				}

			} catch (RuntimeException | InterruptedException e) {
				e.printStackTrace();
			}
		});

		escreverArquivo("arquivoProcessado.csv", linhas);

	}

	private static String contaComDigito(String conta) {
		StringBuilder builder = new StringBuilder(conta);
        builder = builder.insert(5,"-");
        return builder.toString();
	}

	private static String geraLinha(String[] contaEnviar) {
		StringBuilder builder = new StringBuilder();

		for (int i = 0; i < contaEnviar.length; i++) {
			builder.append(contaEnviar[i]);
			builder.append(";");
		}

		return builder.toString();
	}

	public static List<String> lerArquivo(String pathArquivo) throws IOException {

		BufferedReader reader = new BufferedReader(new FileReader(pathArquivo));

		List<String> linhas = new ArrayList<>();
		reader.readLine();

		int count = 1;
		while (reader.ready()) {
			if (count == 1) {
				count++;
				continue;
			}
			String linha = reader.readLine();
			linhas.add(linha);
		}

		reader.close();

		return linhas;
	}

	public static void escreverArquivo(String pathArquivo, List<String> linhas) throws IOException {

		File file = new File(pathArquivo);

		if (!file.exists()) {
			System.out.println(pathArquivo + " criado");
		} else {
			System.out.println(pathArquivo+ " foi alterado");
		}

		BufferedWriter write = new BufferedWriter(new FileWriter(file));
		write.append("agencia;conta;saldo;status;resultado\n");
		linhas.forEach(linha -> {

			try {
				write.append(linha + "\n");
			} catch (IOException e) {
				e.printStackTrace();
			}

		});
		write.close();
	}

}
